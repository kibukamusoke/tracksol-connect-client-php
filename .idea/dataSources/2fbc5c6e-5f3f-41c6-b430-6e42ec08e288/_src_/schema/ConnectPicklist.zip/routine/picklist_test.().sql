CREATE PROCEDURE picklist_test()
  BEGIN


    SET @location_rows := 0;
    SET @doc_counter := 0;
    SET @neg_counter := 0;

    SELECT
      type_id                          AS node,
      name                             AS description,
      @neg_counter := @neg_counter - 1 AS tmn_ref_id,
      1                                AS is_parent,
      code                             AS type_short,
      name                             AS type_long
    FROM pkl_document_type
    WHERE status = 0

    UNION ALL

    SELECT
      CONCAT(type_id, '.', @doc_counter := @doc_counter + 1) AS node,
      code                                                  AS description,
      @neg_counter := @neg_counter - 1                      AS tmn_ref_id,
      1                                                     AS is_parent,
      type_code                                                  AS type_short,
      name                                                  AS type_long
    FROM
      (
        SELECT
          A.type_id,
          B.code,
          A.code AS type_code,
          A.name
        FROM
          pkl_document_type A
          INNER JOIN pkl_picklist B ON A.status = 0 AND B.status = 0 AND A.type_id = B.type_id
        GROUP BY A.code ORDER BY A.type_id ASC
      ) AS AA;



    /**
  SELECT
    CONCAT(type_id, '.', @location_rows := @location_rows + 1) AS node,
    code                                                       AS description,
    @neg_counter := @neg_counter - 1                           AS tmn_ref_id,
    1                                                          AS is_parent,
    type_code                                                  AS type_short,
    type_name                                                  AS type_long
  FROM
    (
      SELECT
        A.type_id,
        B.picklist_id,
        B.source_location_id,
        C.name,
        B.code,
        D.code AS type_code,
        D.name AS type_name
      FROM pkl_picklist A
        INNER JOIN pkl_document_type D ON D.status = 0 AND A.type_id = D.type_id
        INNER JOIN pkl_picklist_item B ON A.idx = B.picklist_id
                                          AND A.status = 0 AND B.status = 0
        INNER JOIN pkl_location C ON B.source_location_id = C.idx AND C.status = 0

      GROUP BY B.picklist_id, B.source_location_id, B.code
      ORDER BY B.picklist_id, B.source_location_id, B.code
    ) AS AA; */


    /*SELECT
      CONCAT(type_id, '.', @location_rows := @location_rows + 1) AS node,
      name                                                       AS description,
      @neg_counter := @neg_counter - 1                           AS tmn_ref_id,
      1                                                          AS is_parent,
      'LOC'                                                      AS type_short,
      'Location'                                                 AS type_long
    FROM
      (
        SELECT
          A.type_id,
          B.picklist_id,
          B.source_location_id,
          C.name
        FROM pkl_picklist A
          INNER JOIN pkl_picklist_item B ON A.idx = B.picklist_id
                                            AND A.status = 0 AND B.status = 0
          INNER JOIN pkl_location C ON B.source_location_id = C.idx AND C.status = 0
        GROUP BY B.picklist_id, B.source_location_id
        ORDER BY B.picklist_id, B.source_location_id
      ) AS AB;*/

  END;
