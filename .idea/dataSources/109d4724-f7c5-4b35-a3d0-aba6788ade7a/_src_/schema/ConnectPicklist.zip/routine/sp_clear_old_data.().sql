CREATE PROCEDURE sp_clear_old_data(OUT `_commands` TEXT)
  BEGIN

    SELECT CONCAT(GROUP_CONCAT(rex SEPARATOR '
'), CHAR(10)) INTO _commands
    FROM (
           SELECT
             DISTINCT CONCAT('{X`D|', tmn_ref_id, '|.PL*|9`}') AS rex
           FROM pkl_picklist_item
         ) X;

  END;
