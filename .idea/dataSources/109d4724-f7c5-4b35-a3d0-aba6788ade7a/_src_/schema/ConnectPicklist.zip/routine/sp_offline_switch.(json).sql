CREATE PROCEDURE sp_offline_switch(IN `_data` JSON, OUT `_response` TINYTEXT)
  BEGIN

    DECLARE _action_id BIGINT;
    DECLARE _tmn_hw_id BIGINT;
    DECLARE _card_no VARCHAR(20);
    DECLARE _version VARCHAR(20);
    DECLARE _txndate DATETIME;
    DECLARE _p131 JSON;


    DECLARE _p33 VARCHAR(255);
    DECLARE _p34 VARCHAR(255);

    DECLARE _is_picklist BOOLEAN;

    IF _is_picklist = TRUE THEN


      CALL sp_offline_picklist(_data, @response);
      SET _response = @response;

      ELSE

      SET _response = 'Action not ready';

    END IF;



  END;
